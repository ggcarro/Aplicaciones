﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProgetoApi.Models
{
    public class Progefile
    {
        public int ID { get; set; }
        public string code { get; set; }
        public string path { get; set; }
        public string filename { get; set; }
    }
}
