﻿namespace Progeto.Geometry
{
    public interface IPrimitive : IDraw
    {
    }
}